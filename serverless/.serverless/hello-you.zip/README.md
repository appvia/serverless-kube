# Template for deploying an app using serverless

## Pre-reqs
* Kube cluster with kubeless installed
* Python 3, kubectl, kubeless CLI and serverless CLI installed

## Install serverless plugin (within project dir)
```
$ sls plugin install --name serverless-kubeless
$ sls plugin install --name serverless-google-cloudfunctions
```

## Deploy to kubeless and expose using ingress
```
$ serverless deploy
```

## Check the function is in READY state
```
$ kubeless function ls
```

